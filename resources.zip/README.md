stone_sword:
1: test sword