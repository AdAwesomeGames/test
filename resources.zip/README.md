Diamond Pickaxe:
 - 5: Drill
 - 11: Blue
 - 12: White
 - 13: Green/Grey
 - 21: Gilded Diamond
 Netherite Pickaxe:
 - 5: Drill
 - 11: Blue
 - 12: White
 - 13: Green/Grey
 - 21: Gilded Netherite